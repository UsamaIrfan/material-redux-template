import Auth from './Auth';
import {combineReducers} from 'redux';

export default combineReducers({
    Auth: Auth
});